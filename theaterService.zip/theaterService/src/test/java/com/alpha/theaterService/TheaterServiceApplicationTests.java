package com.alpha.theaterService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheaterServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
